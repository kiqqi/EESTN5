// funciones.js

document.addEventListener('DOMContentLoaded', function() {
    // Accedemos al elemento h1
    var elementoH1 = document.getElementById('contador');
    
    // Accedemos al nodo de texto dentro del elemento h1
    var nodoTexto = elementoH1.childNodes[0];
    
    // Convertimos el valor del nodo de texto a entero, sumamos uno y lo asignamos de nuevo
    var valor = parseInt(nodoTexto.nodeValue);
    valor++;
    nodoTexto.nodeValue = valor;
  });
  