function definirAtributo() {
    let reftabla = document.getElementById('tabla1')
    reftabla.setAttribute('border', '5')
}

function borrarAtributo() {
    let reftabla = document.getElementById('tabla1')
    reftabla.removeAttribute('border')
}