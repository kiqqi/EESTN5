document.getElementById('selector').addEventListener('change', (e) => {
    alert('El valor seleccionado es:' + e.target.value)
})