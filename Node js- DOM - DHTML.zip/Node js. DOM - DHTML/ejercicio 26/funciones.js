function concatenar(objeto) {
    let ref = document.getElementById('titulo')
    ref.innerText += objeto.value
}