// funciones.js

document.addEventListener("DOMContentLoaded", function() {
    var div1 = document.getElementById("div1");
    var div2 = document.getElementById("div2");
    var btnContarNodos = document.getElementById("btnContarNodos");
    var btnContarElementos = document.getElementById("btnContarElementos");

    btnContarNodos.addEventListener("click", function() {
        var cantidadNodosDiv1 = div1.childNodes.length;
        var cantidadNodosDiv2 = div2.childNodes.length;
        alert("Cantidad de nodos hijos de div1: " + cantidadNodosDiv1 + "\nCantidad de nodos hijos de div2: " + cantidadNodosDiv2);
    });

    btnContarElementos.addEventListener("click", function() {
        var cantidadElementosDiv1 = div1.children.length;
        var cantidadElementosDiv2 = div2.children.length;
        alert("Cantidad de elementos hijos de div1: " + cantidadElementosDiv1 + "\nCantidad de elementos hijos de div2: " + cantidadElementosDiv2);
    });
});
