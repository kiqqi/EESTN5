// funciones.js

document.addEventListener("DOMContentLoaded", function() {
    var parrafo = document.getElementById("parrafo");
    var btnPequena = document.getElementById("btnPequena");
    var btnMediana = document.getElementById("btnMediana");
    var btnGrande = document.getElementById("btnGrande");

    btnPequena.addEventListener("click", function() {
        parrafo.style.fontSize = "10px";
    });

    btnMediana.addEventListener("click", function() {
        parrafo.style.fontSize = "13px";
    });

    btnGrande.addEventListener("click", function() {
        parrafo.style.fontSize = "20px";
    });
});
