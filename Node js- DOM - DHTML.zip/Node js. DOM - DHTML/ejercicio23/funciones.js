function cambiarEstiloLista() {
    let pun = document.getElementById('listapaises')
    let punselect = document.getElementById('estilolista')
    pun.style.listStyleType = punselect.value
}