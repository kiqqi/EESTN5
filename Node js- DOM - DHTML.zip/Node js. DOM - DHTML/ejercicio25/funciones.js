function redireccionarGoogle() {
    window.location = 'https://www.google.com'
}

function redireccionarMSN() {
    window.location = 'https://www.msn.com'
}